# Pesa sa Haraka

A starter platform for discovering and applying to online work and business opportunities.

## Run locally
1. Install Python 3.10+.
2. Run `python -m venv .venv` and activate it.
3. Run `pip install -r requirements.txt`.
4. Run `python app.py`.
5. Open http://127.0.0.1:5000

The app creates a local SQLite database automatically.

## Deployment
Deploy as a Python web service using `gunicorn app:app`. Set a strong random `SECRET_KEY` environment variable and configure persistent storage for `pesa.db` (or configure `DATABASE_PATH`).

## Important before accepting real money
This is a starter application, not a verified marketplace or live payment system. Sample listings are clearly marked as examples. Before public commercial use, verify every provider and listing, publish clear fees/refund/reward terms, add privacy and customer-support policies, secure and test the deployment, and integrate M-Pesa through an approved Daraja/business account with server-side payment verification. Never ask users for their M-Pesa PIN or OTP. Do not promise earnings or guaranteed rewards.
