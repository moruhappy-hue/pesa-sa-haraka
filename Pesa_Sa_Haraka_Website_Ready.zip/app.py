import os, sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-before-deployment")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "pesa.db"))

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS opportunities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL, category TEXT NOT NULL,
      description TEXT NOT NULL, provider TEXT NOT NULL,
      location TEXT DEFAULT 'Online', status TEXT DEFAULT 'Review required',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL, opportunity_id INTEGER NOT NULL,
      message TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, opportunity_id),
      FOREIGN KEY(user_id) REFERENCES users(id),
      FOREIGN KEY(opportunity_id) REFERENCES opportunities(id)
    );
    """)
    count = conn.execute("SELECT COUNT(*) FROM opportunities").fetchone()[0]
    if count == 0:
        conn.executemany(
            "INSERT INTO opportunities(title,category,description,provider,location) VALUES(?,?,?,?,?)",
            [
              ("Hotel guest-experience feedback", "Hospitality", "A sample listing for hotels seeking structured guest feedback. Confirm the hotel and assignment details before participating.", "Pesa sa Haraka review team", "Kenya"),
              ("Restaurant service evaluation", "Hospitality", "A sample opportunity to evaluate service quality. Participation and any compensation must be agreed with the verified business in advance.", "Pesa sa Haraka review team", "Kenya"),
              ("Website and app usability testing", "Technology", "Give feedback on a website or app interface. Never share passwords, PINs or one-time codes.", "Pesa sa Haraka review team", "Online"),
              ("Online research and surveys", "Research", "A sample research listing. Check eligibility, time required and payment terms with the named research provider.", "Pesa sa Haraka review team", "Online")
            ])
    conn.commit()
    conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please sign in to continue.", "info")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    items = db().execute("SELECT * FROM opportunities ORDER BY id DESC LIMIT 6").fetchall()
    return render_template("index.html", opportunities=items)

@app.route("/opportunities")
def opportunities():
    items = db().execute("SELECT * FROM opportunities ORDER BY id DESC").fetchall()
    return render_template("opportunities.html", opportunities=items)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter your name, a valid email and a password of at least 8 characters.", "error")
        else:
            try:
                db().execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                             (name, email, generate_password_hash(password)))
                db().commit()
                flash("Account created. You can now sign in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That email is already registered.", "error")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            return redirect(url_for("dashboard"))
        flash("Email or password is incorrect.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have signed out.", "info")
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    rows = db().execute("""SELECT opportunities.*, applications.created_at AS applied_at
        FROM applications JOIN opportunities ON opportunities.id=applications.opportunity_id
        WHERE applications.user_id=? ORDER BY applications.id DESC""", (session["user_id"],)).fetchall()
    return render_template("dashboard.html", applications=rows)

@app.route("/apply/<int:opportunity_id>", methods=["POST"])
@login_required
def apply(opportunity_id):
    exists = db().execute("SELECT id FROM opportunities WHERE id=?", (opportunity_id,)).fetchone()
    if not exists:
        flash("Opportunity not found.", "error")
    else:
        try:
            db().execute("INSERT INTO applications(user_id,opportunity_id,message) VALUES(?,?,?)",
                         (session["user_id"], opportunity_id, request.form.get("message", "").strip()))
            db().commit()
            flash("Your interest has been submitted. The provider must verify the opportunity and terms.", "success")
        except sqlite3.IntegrityError:
            flash("You have already expressed interest in this opportunity.", "info")
    return redirect(url_for("opportunities"))

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404

@app.route("/health")
def health():
    return {"status": "ok"}

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
